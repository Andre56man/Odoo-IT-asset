from odoo import fields, models, api
import base64
import io
import xlsxwriter

class EquipmentExportWizard(models.TransientModel):
    _name = 'it.equipment.export.wizard'
    _description = 'Equipment Export Wizard'

    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_it_client', '=', True)])
    export_format = fields.Selection([
        ('xlsx', 'Excel'),
        ('csv', 'CSV')
    ], string="Export Format", default='xlsx')

    data = fields.Binary('Export File', readonly=True)
    filename = fields.Char('Filename')

    def action_export(self):
        domain = [('client_id', '=', self.client_id.id)] if self.client_id else []
        assets = self.env['it.asset'].search(domain)
        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output)
        sheet = workbook.add_worksheet('Assets')

        headers = ['Name', 'Equipment Type', 'Status', 'Purchase Date', 'Value']
        for col, header in enumerate(headers):
            sheet.write(0, col, header)

        for row, asset in enumerate(assets, 1):
            sheet.write(row, 0, asset.name)
            sheet.write(row, 1, asset.equipment_type_id.name or '')
            sheet.write(row, 2, asset.status or '')
            sheet.write(row, 3, str(asset.purchase_date) or '')
            sheet.write(row, 4, asset.value or 0)

        workbook.close()
        output.seek(0)
        file_data = output.read()
        output.close()

        self.write({
            'data': base64.b64encode(file_data),
            'filename': 'assets_export.xlsx'
        })

        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content?model={self._name}&id={self.id}&field=data&filename=assets_export.xlsx&download=true',
            'target': 'self',
        }

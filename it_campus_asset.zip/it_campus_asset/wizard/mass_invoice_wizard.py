from odoo import fields, models, api

class MassInvoiceWizard(models.TransientModel):
    _name = 'it.mass.invoice.wizard'
    _description = 'Mass Invoice Wizard'

    contract_ids = fields.Many2many('it.contract', string="Contracts")

    def action_generate_invoices(self):
        for contract in self.contract_ids:
            billing_plan = contract.billing_plan_id
            if billing_plan and billing_plan.amount > 0:
                invoice = self.env['account.move'].create({
                    'move_type': 'out_invoice',
                    'partner_id': contract.client_id.id,
                    'invoice_date': fields.Date.today(),
                    'invoice_date_due': fields.Date.today() + timedelta(days=billing_plan.due_date_days),
                    'invoice_line_ids': [(0, 0, {
                        'name': f"Invoice for {contract.name}",
                        'quantity': 1.0,
                        'price_unit': billing_plan.amount,
                        'account_id': self.env['account.account'].search([('user_type_id.type', '=', 'receivable')], limit=1).id,
                    })]
                })
                invoice.action_post()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'tree',
            'domain': [('move_type', '=', 'out_invoice')],
            'target': 'current',
        }
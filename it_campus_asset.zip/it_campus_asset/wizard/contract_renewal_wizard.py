from odoo import fields, models, api
from datetime import timedelta

class ContractRenewalWizard(models.TransientModel):
    _name = 'it.contract.renewal.wizard'
    _description = 'Contract Renewal Wizard'

    contract_id = fields.Many2one('it.contract', string="Contract", required=True)
    new_end_date = fields.Date(string="New End Date", required=True)
    new_amount = fields.Float(string="New Amount", default=lambda self: self.contract_id.amount)

    def action_renew_contract(self):
        self.contract_id.write({
            'end_date': self.new_end_date,
            'amount': self.new_amount,
        })
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'it.contract',
            'res_id': self.contract_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
from odoo import fields, models, api
import base64
import csv
from io import StringIO

class EquipmentImportWizard(models.TransientModel):
    _name = 'it.equipment.import.wizard'
    _description = 'Equipment Import Wizard'

    file = fields.Binary(string="File", required=True)
    file_name = fields.Char(string="File Name")
    client_id = fields.Many2one('res.partner', string="Client", domain=[('is_it_client', '=', True)], required=True)

    def action_import(self):
        if not self.file:
            raise ValidationError("No file provided.")
        
        file_data = base64.b64decode(self.file).decode('utf-8')
        csv_reader = csv.reader(StringIO(file_data))
        headers = next(csv_reader)  # Skip header row

        for row in csv_reader:
            if len(row) < 5:
                continue  # Skip incomplete rows
            self.env['it.asset'].create({
                'name': row[0],
                'equipment_type_id': self.env['it.equipment.type'].search([('name', '=', row[1])], limit=1).id,
                'client_id': self.client_id.id,
                'status': row[2],
                'purchase_date': row[3],
                'value': float(row[4]),
            })

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'it.asset',
            'view_mode': 'tree',
            'target': 'current',
        }
from odoo import fields, models, api
from datetime import timedelta  # ✅ à ajouter

class AlertGeneratorWizard(models.TransientModel):
    _name = 'it.alert.generator.wizard'
    _description = 'Alert Generator Wizard'

    asset_ids = fields.Many2many('it.asset', string="Assets")

    def action_generate_alerts(self):
        for asset in self.asset_ids:
            if asset.warranty_end_date and asset.warranty_end_date <= fields.Date.today() + timedelta(days=30):
                self.env['it.alert'].create({
                    'name': f"Warranty Alert for {asset.name}",
                    'alert_type_id': self.env.ref('it_campus_asset.alert_type_warranty').id,
                    'asset_id': asset.id,
                    'trigger_date': asset.warranty_end_date,
                })
        return {'type': 'ir.actions.act_window_close'}

from odoo import api, models

class InvoiceGenerator(models.AbstractModel):
    _name = 'it.invoice.generator'

    @api.model
    def generate_invoices(self):
        billing_plans = self.env['it.billing.plan'].search([('contract_id', '!=', False)])
        for plan in billing_plans:
            if plan.contract_id and plan.amount > 0:
                invoice = self.env['account.move'].create({
                    'move_type': 'out_invoice',
                    'partner_id': plan.contract_id.client_id.id,
                    'invoice_date': fields.Date.today(),
                    'invoice_date_due': fields.Date.today() + timedelta(days=plan.due_date_days),
                    'invoice_line_ids': [(0, 0, {
                        'name': f"Invoice for {plan.name}",
                        'quantity': 1.0,
                        'price_unit': plan.amount,
                        'account_id': self.env['account.account'].search([('user_type_id.type', '=', 'receivable')], limit=1).id,
                    })]
                })
                invoice.action_post()
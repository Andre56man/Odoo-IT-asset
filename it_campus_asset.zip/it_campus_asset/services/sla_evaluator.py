from odoo import api, models

class SLAEvaluator(models.AbstractModel):
    _name = 'it.sla.evaluator'

    @api.model
    def evaluate_sla(self, incident):
        sla_template = incident.sla_template_id
        if sla_template:
            return sla_template.evaluate_sla(incident)
        return {'status': 'no_sla', 'penalty': 0.0}
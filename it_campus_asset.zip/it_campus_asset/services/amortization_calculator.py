from odoo import api, models

class AmortizationCalculator(models.AbstractModel):
    _name = 'it.amortization.calculator'

    @api.model
    def calculate_amortization(self):
        amortizations = self.env['it.amortization'].search([])
        for amort in amortizations:
            amort._compute_remaining_value()
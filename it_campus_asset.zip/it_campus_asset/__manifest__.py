{
    'name': 'It campus manager',
    'version': '18.0.1.0.0',
    'summary': 'Comprehensive IT campus manage for Service Providers',
    'description': """
        A complete module for IT campus manage inspired by GLPI, integrated with Odoo ERP
        
    """,
    'category': 'Services/IT',
    'author': 'Kodjo Koua Andre',
    'website': 'https://odoo.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'sale',
        'account',
        'stock',
        'hr',
        'helpdesk',
        'portal',
        'sale_subscription',
        'web',
        'board',
    ],
    'data': [
        # Security
        'security/groups.xml',
        'security/ir.model.access.csv',
        'security/record_rules.xml',

        # Configuration data
        'data/sequences.xml',
        'data/intervention_types.xml',
        'data/alert_types.xml',
        'data/ir.cron.xml',
        'data/sla_template.xml',
        'data/invoice_plan_template.xml',
        'data/equipment_types.xml',
        'data/demo_data.xml',

        # Main views (pay attention to loading order)
        # First load all view definitions
        'views/department_views.xml',
        'views/warranty_views.xml',
        'views/alert_views.xml',
        'views/amortization_views.xml',
        'views/billing_plan_views.xml',
        'views/client_views.xml',
        'views/contract_views.xml',
        'views/equipment_type_views.xml',
        'views/incident_views.xml',
        'views/intervention_views.xml',
        'views/invoice_views.xml',
        'views/iot_integration_views.xml',
        'views/license_views.xml',
        'views/maintenance_views.xml',
        'views/site_views.xml',
        'views/sla_views.xml',
        'views/supplier_views.xml',
        'views/technician_views.xml',
        'views/user_final_views.xml',
        'views/equipment_type_views.xml',
        'views/dashboard_views.xml',
        
        # Then load actions which reference the views
        'views/actions.xml',
        
        # Finally load menu which references the actions
        'views/menu.xml',
        
        # Portal templates (can be loaded last)
        'views/portal_templates.xml',

        # Reports
        'reports/report_amortization.xml',
        'reports/report_contract.xml',
        'reports/report_equipment.xml',
        'reports/report_incident.xml',
        'reports/report_intervention.xml',
        'reports/report_inventory.xml',
        'reports/report_invoice.xml',
        'reports/report_sla.xml',

        # Wizards
        'wizard/alert_generator_views.xml',
        'wizard/contract_renewal_views.xml',
        'wizard/equipment_export_views.xml',
        'wizard/equipment_import_views.xml',
        'wizard/mass_invoice_views.xml',
    ],

    'demo': [
        'demo/demo_incidents.xml',
        'demo/demo_contracts.xml',
    ],

    'assets': {
        'web.assets_backend': [
            'it_campus_asset/static/src/js/dashboard.js',
            'it_campus_asset/static/src/scss/dashboard.scss',
        ],
        'web.assets_frontend': [
            'it_campus_asset/static/src/js/portal.js',
            'it_campus_asset/static/src/scss/portal.scss',
        ],
    },
  
    'icon': '/it_campus_asset/static/description/icon.png',
    'installable': True,
    'application': True,
    'auto_install': False,
}
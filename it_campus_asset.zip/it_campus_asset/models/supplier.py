from odoo import models, fields, api, _

class ITSupplier(models.Model):
    _name = 'it.supplier'
    _description = 'IT Supplier'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Supplier Name', required=True, tracking=True)
    partner_id = fields.Many2one('res.partner', string='Related Partner', required=True, tracking=True)
    contact_name = fields.Char(string='Contact Person', tracking=True)
    phone = fields.Char(string='Phone', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    website = fields.Char(string='Website', tracking=True)
    
    
    # Modifiez cette relation many2many pour utiliser une table et des colonnes différentes
    channel_ids = fields.Many2many(
        'mail.channel', 
        'it_supplier_mail_channel_rel',  # Nom de table personnalisée
        'supplier_id',                   # Colonne pour l'ID du fournisseur
        'channel_id',                    # Colonne pour l'ID du canal
        string='Communication Channels'
    )
    
    contract_ids = fields.One2many('it.contract', 'supplier_id', string='Contracts')
    asset_ids = fields.One2many('it.asset', 'supplier_id', string='Supplied Assets')
    license_ids = fields.One2many('it.license', 'supplier_id', string='Licenses')
    
    contract_count = fields.Integer(string='Contract Count', compute='_compute_counts')
    asset_count = fields.Integer(string='Asset Count', compute='_compute_counts')
    license_count = fields.Integer(string='License Count', compute='_compute_counts')
    
    active = fields.Boolean(default=True, tracking=True)
    notes = fields.Text(string='Notes')
    
    supplier_type = fields.Selection([
        ('hardware', 'Hardware'),
        ('software', 'Software'),
        ('service', 'Service'),
        ('mixed', 'Mixed'),
    ], string='Supplier Type', default='mixed', tracking=True)
    
    @api.depends('contract_ids', 'asset_ids', 'license_ids')
    def _compute_counts(self):
        for supplier in self:
            supplier.contract_count = len(supplier.contract_ids)
            supplier.asset_count = len(supplier.asset_ids)
            supplier.license_count = len(supplier.license_ids)
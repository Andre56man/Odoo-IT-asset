from odoo import api, fields, models

class ITSLATemplate(models.Model):
    _name = 'it.sla.template'
    _description = 'SLA Template'

    name = fields.Char(string="SLA Name", required=True)
    response_time = fields.Integer(string="Response Time (Hours)", required=True)
    resolution_time = fields.Integer(string="Resolution Time (Hours)", required=True)
    penalty_rate = fields.Float(string="Penalty Rate (%)", required=True)
    availability = fields.Float(string="Availability (%)", required=True)

    def evaluate_sla(self, incident):
        self.ensure_one()
        if incident.status == 'resolved':
            resolution_time = (fields.Datetime.now() - incident.create_date).total_seconds() / 3600
            if resolution_time > self.resolution_time:
                penalty = (resolution_time - self.resolution_time) * self.penalty_rate / 100
                return {'status': 'violated', 'penalty': penalty}
            return {'status': 'met', 'penalty': 0.0}
        return {'status': 'pending', 'penalty': 0.0}

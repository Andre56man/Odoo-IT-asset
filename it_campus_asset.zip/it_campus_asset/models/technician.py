from odoo import models, fields, api, _

class ITTechnician(models.Model):
    _name = 'it.technician'
    _description = 'IT Technician'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', required=True, tracking=True)
    employee_id = fields.Many2one('hr.employee', string='Related Employee', tracking=True)
    phone = fields.Char(string='Phone', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    
    # Ajout du champ manquant pour la relation avec les sites
    site_ids = fields.Many2many(
        'it.site',
        'it_technician_site_rel',
        'technician_id',
        'site_id',
        string='Sites'
    )
    
    # Modifiez cette relation many2many pour utiliser une table et des colonnes différentes
    category_ids = fields.Many2many(
        'hr.employee.category',
        'it_technician_category_rel',  # Nom de table personnalisée
        'technician_id',              # Colonne pour l'ID du technicien
        'category_id',                # Colonne pour l'ID de la catégorie
        string='Tags'
    )
    
    intervention_ids = fields.One2many('it.intervention', 'technician_id', string='Interventions')
    maintenance_ids = fields.One2many('it.maintenance', 'technician_id', string='Maintenance Tasks')
    
    intervention_count = fields.Integer(string='Intervention Count', compute='_compute_counts')
    maintenance_count = fields.Integer(string='Maintenance Count', compute='_compute_counts')
    
    active = fields.Boolean(default=True, tracking=True)
    notes = fields.Text(string='Notes')
    
    expertise_level = fields.Selection([
        ('junior', 'Junior'),
        ('intermediate', 'Intermediate'),
        ('senior', 'Senior'),
        ('expert', 'Expert'),
    ], string='Expertise Level', default='intermediate', tracking=True)
    
    specialization = fields.Selection([
        ('network', 'Network'),
        ('hardware', 'Hardware'),
        ('software', 'Software'),
        ('security', 'Security'),
        ('support', 'Support'),
        ('generalist', 'Generalist'),
    ], string='Specialization', default='generalist', tracking=True)
    
    availability = fields.Selection([
        ('available', 'Available'),
        ('busy', 'Busy'),
        ('on_leave', 'On Leave'),
    ], string='Availability', default='available', tracking=True)
    
    @api.depends('intervention_ids', 'maintenance_ids')
    def _compute_counts(self):
        for technician in self:
            technician.intervention_count = len(technician.intervention_ids)
            technician.maintenance_count = len(technician.maintenance_ids)
from odoo import api, fields, models

class ITMaintenance(models.Model):
    _name = 'it.maintenance'
    _description = 'IT Maintenance'

    name = fields.Char(string="Maintenance Name", required=True)
    asset_id = fields.Many2one('it.asset', string="Asset", required=True)
    technician_id = fields.Many2one('it.technician', string="Technician", required=True)
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date")
    frequency = fields.Selection([
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly')
    ], string="Frequency", default='monthly')
    status = fields.Selection([
        ('planned', 'Planned'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed')
    ], string="Status", default='planned')
    report = fields.Text(string="Report")
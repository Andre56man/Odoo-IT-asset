from odoo import fields, models

class ITIoTIntegration(models.Model):
    _name = 'it.iot.integration'
    _description = 'IoT Integration'

    name = fields.Char(string="Integration Name", required=True)
    asset_id = fields.Many2one('it.asset', string="Asset")
    sensor_data = fields.Text(string="Sensor Data")
    last_update = fields.Datetime(string="Last Update")
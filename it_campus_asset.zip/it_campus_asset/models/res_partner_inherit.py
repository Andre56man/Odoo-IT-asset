from odoo import fields, models

class ResPartner(models.Model):
    _inherit = 'res.partner'

    # Champs client IT
    is_it_client = fields.Boolean(string="IT Client")
    site_ids = fields.One2many('it.site', 'client_id', string="Sites")
    contract_ids = fields.One2many('it.contract', 'client_id', string="Contracts")
    asset_ids = fields.One2many('it.asset', 'client_id', string="Assets")

    # Champs fournisseur IT
    is_it_supplier = fields.Boolean(string="IT Supplier")
    supplied_asset_ids = fields.One2many('it.asset', 'supplier_id', string="Supplied Assets")
    supplied_license_ids = fields.One2many('it.license', 'supplier_id', string="Supplied Licenses")
    support_contract_ids = fields.One2many('it.contract', 'supplier_id', string="Support Contracts")

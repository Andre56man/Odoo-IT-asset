from odoo import fields, models, api
from odoo.exceptions import ValidationError
from datetime import date

class ITWarranty(models.Model):
    _name = 'it.warranty'
    _description = 'IT Warranty'

    asset_id = fields.Many2one('it.asset', string="Asset", required=True, ondelete='cascade')
    warranty_type = fields.Selection([
        ('standard', 'Standard'),
        ('extended', 'Extended')
    ], string="Warranty Type", default='standard')
    start_date = fields.Date(string="Start Date", related='asset_id.purchase_date', store=True)
    end_date = fields.Date(string="End Date", required=True)
    supplier_id = fields.Many2one('it.supplier', string="Supplier")
    auto_renew = fields.Boolean(string="Auto Renew")

    is_expired = fields.Boolean(string="Expired", compute='_compute_is_expired', store=True)

    @api.depends('end_date')
    def _compute_is_expired(self):
        today = date.today()
        for record in self:
            record.is_expired = record.end_date < today if record.end_date else False

    @api.constrains('start_date', 'end_date')
    def _check_warranty_dates(self):
        for record in self:
            if record.start_date and record.end_date and record.start_date > record.end_date:
                raise ValidationError("Warranty end date cannot be before start date.")

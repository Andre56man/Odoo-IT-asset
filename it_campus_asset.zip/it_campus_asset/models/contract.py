from odoo import api, fields, models

class ITContract(models.Model):
    _name = 'it.contract'
    _description = 'IT Contract'
    
    name = fields.Char(string="Contract Name", required=True)
    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)], required=True)
    start_date = fields.Date(string="Start Date", required=True)
    # Modifié: pointer vers it.supplier au lieu de res.partner
    supplier_id = fields.Many2one('it.supplier', string="Supplier")
    
    end_date = fields.Date(string="End Date")
    billing_frequency = fields.Selection([
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly')
    ], string="Billing Frequency", default='monthly')
    amount = fields.Float(string="Total Amount", required=True)
    sla_template_id = fields.Many2one('it.sla.template', string="SLA Template")
    billing_plan_id = fields.Many2one('it.billing.plan', string="Billing Plan")
    asset_ids = fields.One2many('it.asset', 'contract_id', string="Assets")
    auto_renew = fields.Boolean(string="Auto Renew")
    
    @api.onchange('client_id')
    def _onchange_client_id(self):
        if self.client_id:
            self.site_id = self.client_id.site_ids[:1].id if self.client_id.site_ids else False
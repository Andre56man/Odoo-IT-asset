from odoo import api, fields, models

class ITInterventionType(models.Model):
    _name = 'it.intervention.type'
    _description = 'Intervention Type'

    name = fields.Char(string="Intervention Type", required=True)

class ITIntervention(models.Model):
    _name = 'it.intervention'
    _description = 'IT Intervention'

    name = fields.Char(string="Intervention Name", required=True, default=lambda self: self.env['ir.sequence'].next_by_code('it.intervention'))
    intervention_type_id = fields.Many2one('it.intervention.type', string="Intervention Type", required=True)
    incident_id = fields.Many2one('it.incident', string="Incident")
    asset_id = fields.Many2one('it.asset', string="Asset", related='incident_id.asset_id')
    technician_id = fields.Many2one('it.technician', string="Technician", required=True)
    start_date = fields.Datetime(string="Start Date", default=fields.Datetime.now)
    end_date = fields.Datetime(string="End Date")
    duration = fields.Float(string="Duration (Hours)", compute='_compute_duration', store=True)
    status = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed')
    ], string="Status", default='draft')
    report = fields.Text(string="Report")

    @api.depends('start_date', 'end_date')
    def _compute_duration(self):
        for record in self:
            if record.start_date and record.end_date:
                delta = record.end_date - record.start_date
                record.duration = delta.total_seconds() / 3600
            else:
                record.duration = 0.0
from odoo import api, fields, models

class ITLicense(models.Model):
    _name = 'it.license'
    _description = 'IT License'

    name = fields.Char(string="License Name", required=True)
    asset_id = fields.Many2one('it.asset', string="Asset")
    client_id = fields.Many2one('res.partner', string="Client", related='asset_id.client_id')
    
    license_type = fields.Selection([
        ('perpetual', 'Perpetual'),
        ('subscription', 'Subscription')
    ], string="License Type", default='subscription')
    expiration_date = fields.Date(string="Expiration Date")
    supplier_id = fields.Many2one('it.supplier', string="Supplier")
    activation_count = fields.Integer(string="Activation Count", default=1)

    @api.constrains('expiration_date')
    def _check_expiration_date(self):
        for record in self:
            if record.expiration_date and record.expiration_date < fields.Date.today():
                raise ValidationError("License expiration date cannot be in the past.")
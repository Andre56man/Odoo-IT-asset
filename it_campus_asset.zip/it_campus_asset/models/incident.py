from odoo import api, fields, models

class ITIncident(models.Model):
    _name = 'it.incident'
    _description = 'IT Incident'
    _inherit = 'helpdesk.ticket'

    name = fields.Char(string="Incident Name", required=True, default=lambda self: self.env['ir.sequence'].next_by_code('it.incident'))
    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)], required=True)
    asset_id = fields.Many2one('it.asset', string="Asset")
    user_final_id = fields.Many2one('it.user.final', string="Reported By")
    technician_id = fields.Many2one('res.users', string="Assigned Technician")

    priority = fields.Selection([
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High')
    ], string="Priority", default='medium')
    status = fields.Selection([
        ('open', 'Open'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('closed', 'Closed')
    ], string="Status", default='open', tracking=True)
    description = fields.Text(string="Description")
    intervention_ids = fields.One2many('it.intervention', 'incident_id', string="Interventions")
    sla_template_id = fields.Many2one('it.sla.template', string="SLA Template", related='asset_id.contract_id.sla_template_id')
    sla_ids = fields.Many2many('helpdesk.sla', string="SLA Policies", relation='it_incident_helpdesk_sla_rel')

    @api.onchange('asset_id')
    def _onchange_asset_id(self):
        if self.asset_id:
            self.client_id = self.asset_id.client_id
            self.user_final_id = self.asset_id.user_final_id
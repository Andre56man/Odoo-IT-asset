from odoo import fields, models

class ITSite(models.Model):
    _name = 'it.site'
    _description = 'IT Site'

    name = fields.Char(string="Site Name", required=True)
    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)], required=True)
    address = fields.Text(string="Address")
    asset_ids = fields.One2many('it.asset', 'site_id', string="Assets")
    
    # Relation corrigée pour correspondre à celle de ITTechnician
    technician_ids = fields.Many2many(
        'it.technician',
        'it_technician_site_rel',
        'site_id',
        'technician_id',
        string="Assigned Technicians"
    )
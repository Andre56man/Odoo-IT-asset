from datetime import timedelta
from odoo import api, fields, models

class ITAmortization(models.Model):
    _name = 'it.amortization'
    _description = 'IT Amortization'

    asset_id = fields.Many2one('it.asset', string="Asset", required=True, ondelete='cascade')
    method = fields.Selection([
        ('linear', 'Linear'),
        ('declining', 'Declining Balance')
    ], string="Amortization Method", default='linear')
    duration_years = fields.Integer(string="Amortization Period (Years)", required=True)
    start_date = fields.Date(string="Start Date", default=fields.Date.today)
    end_date = fields.Date(string="End Date", compute='_compute_end_date', store=True)
    remaining_value = fields.Float(string="Remaining Value", compute='_compute_remaining_value', store=True)
    total_value = fields.Float(related='asset_id.value', string="Total Value")

    @api.depends('start_date', 'duration_years')
    def _compute_end_date(self):
        for record in self:
            if record.start_date and record.duration_years:
                record.end_date = record.start_date + timedelta(days=record.duration_years * 365)

    @api.depends('total_value', 'start_date', 'end_date')
    def _compute_remaining_value(self):
        for record in self:
            if record.start_date and record.end_date and record.total_value:
                years_passed = (fields.Date.today() - record.start_date).days / 365
                if record.method == 'linear':
                    annual_depreciation = record.total_value / record.duration_years
                    record.remaining_value = max(0, record.total_value - (annual_depreciation * years_passed))
                elif record.method == 'declining':
                    rate = 2 / record.duration_years
                    record.remaining_value = record.total_value * (1 - rate) ** years_passed
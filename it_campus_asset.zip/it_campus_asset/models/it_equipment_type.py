from odoo import models, fields

class EquipmentType(models.Model):
    _name = 'it.equipment.type'
    _description = 'Equipment Type'

    name = fields.Char(required=True)
    default_amortization_years = fields.Integer()
    average_purchase_value = fields.Float()

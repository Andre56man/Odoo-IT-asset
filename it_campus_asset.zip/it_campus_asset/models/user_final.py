from odoo import fields, models

class ITUserFinal(models.Model):
    _name = 'it.user.final'
    _description = 'IT Final User'

    name = fields.Char(string="User Name", required=True)
    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)], required=True)
    department_id = fields.Many2one('it.department', string="Department")
    site_id = fields.Many2one('it.site', string="Site")
    asset_ids = fields.One2many('it.asset', 'user_final_id', string="Assigned Assets")
    incident_ids = fields.One2many('it.incident', 'user_final_id', string="Reported Incidents")
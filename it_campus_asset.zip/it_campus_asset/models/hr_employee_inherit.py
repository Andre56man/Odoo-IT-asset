from odoo import fields, models

class ResPartnerInherit(models.Model):
    _inherit = 'res.partner'

    is_it_client = fields.Boolean(string="IT Client")
    site_ids = fields.One2many('it.site', 'client_id', string="Sites")
    contract_ids = fields.One2many('it.contract', 'client_id', string="Contracts")
    asset_ids = fields.One2many('it.asset', 'client_id', string="Assets")
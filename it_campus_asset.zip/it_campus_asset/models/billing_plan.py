from datetime import timedelta
from odoo import api, fields, models

class ITBillingPlan(models.Model):
    _name = 'it.billing.plan'
    _description = 'IT Billing Plan'

    name = fields.Char(string="Billing Plan Name", required=True)
    frequency = fields.Selection([
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly')
    ], string="Billing Frequency", default='monthly')
    amount = fields.Float(string="Amount", required=True)
    due_date_days = fields.Integer(string="Due Date (Days)", default=30)
    contract_id = fields.Many2one('it.contract', string="Contract")

    def generate_invoices(self):
        for plan in self:
            if plan.contract_id and plan.amount > 0:
                invoice = self.env['account.move'].create({
                    'move_type': 'out_invoice',
                    'partner_id': plan.contract_id.client_id.id,
                    'invoice_date': fields.Date.today(),
                    'invoice_date_due': fields.Date.today() + timedelta(days=plan.due_date_days),
                    'invoice_line_ids': [(0, 0, {
                        'name': f"Invoice for {plan.name}",
                        'quantity': 1.0,
                        'price_unit': plan.amount,
                        'account_id': self.env['account.account'].search([('user_type_id.type', '=', 'receivable')], limit=1).id,
                    })]
                })
                invoice.action_post()
from odoo import models, fields

class ItAssetInvoicePlanTemplate(models.Model):
    _name = 'it.asset.invoice.plan.template'
    _description = 'IT Asset Invoice Plan Template'

    name = fields.Char(required=True)
    description = fields.Text()
    recurrence_type = fields.Selection([
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ], default='monthly', required=True)
    recurrence_interval = fields.Integer(default=1)
    invoice_count = fields.Integer(default=1)

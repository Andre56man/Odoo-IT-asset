from odoo import fields, models

class ITDepartment(models.Model):
    _name = 'it.department'
    _description = 'IT Department'
    _inherit = 'hr.department'

    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)])
    site_id = fields.Many2one('it.site', string="Site")
    user_final_ids = fields.One2many('it.user.final', 'department_id', string="Users")
    asset_ids = fields.One2many('it.asset', 'department_id', string="Assets")
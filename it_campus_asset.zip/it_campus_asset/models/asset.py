from odoo import api, fields, models
from odoo.exceptions import ValidationError

class ITAsset(models.Model):
    _name = 'it.asset'
    _description = 'IT Asset'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    name = fields.Char(string="Asset Name", required=True)
    equipment_type_id = fields.Many2one('it.equipment.type', string="Equipment Type", required=True)
    client_id = fields.Many2one('res.partner', string="Client", domain=[('customer_rank', '>', 0)])
    # Modifié: pointer vers it.supplier au lieu de res.partner
    supplier_id = fields.Many2one('it.supplier', string="Supplier")
    site_id = fields.Many2one('it.site', string="Site")
    user_final_id = fields.Many2one('it.user.final', string="Assigned User")
    purchase_date = fields.Date(string="Purchase Date", required=True)
    warranty_end_date = fields.Date(string="Warranty End Date")
    status = fields.Selection([
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('repair', 'In Repair')
    ], string="Status", default='active', tracking=True)
    license_ids = fields.One2many('it.license', 'asset_id', string="Licenses")
    contract_id = fields.Many2one('it.contract', string="Contract")
    alert_ids = fields.One2many('it.alert', 'asset_id', string="Alerts")
    amortization_id = fields.Many2one('it.amortization', string="Amortization")
    serial_number = fields.Char(string="Serial Number")
    value = fields.Float(string="Purchase Value", required=True)
    image = fields.Binary(string="Image")
    department_id = fields.Many2one('it.department', string="Department")
    
    @api.constrains('purchase_date', 'warranty_end_date')
    def _check_warranty_dates(self):
        for record in self:
            if record.warranty_end_date and record.purchase_date > record.warranty_end_date:
                raise ValidationError("Warranty end date cannot be before purchase date.")
    
    @api.onchange('equipment_type_id')
    def _onchange_equipment_type(self):
        if self.equipment_type_id:
            self.value = self.equipment_type_id.average_purchase_value
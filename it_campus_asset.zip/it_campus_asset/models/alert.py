from odoo import api, fields, models
from datetime import timedelta

class ITAlertType(models.Model):
    _name = 'it.alert.type'
    _description = 'Alert Type'

    name = fields.Char(string="Alert Type", required=True)
    code = fields.Char(string="Code", required=True)

class ITAlert(models.Model):
    _name = 'it.alert'
    _description = 'IT Alert'
    _inherit = ['mail.thread']

    name = fields.Char(string="Alert Name", required=True)
    alert_type_id = fields.Many2one('it.alert.type', string="Alert Type", required=True)
    asset_id = fields.Many2one('it.asset', string="Asset")
    client_id = fields.Many2one('res.partner', string="Client", related='asset_id.client_id')
    trigger_date = fields.Date(string="Trigger Date")
    status = fields.Selection([
        ('pending', 'Pending'),
        ('resolved', 'Resolved')
    ], string="Status", default='pending')
    description = fields.Text(string="Description")

    def create_alerts_for_demo(self):
        assets = self.env['it.asset'].search([])
        for asset in assets:
            if asset.warranty_end_date and asset.warranty_end_date <= fields.Date.today() + timedelta(days=30):
                self.create({
                    'name': f"Warranty Alert for {asset.name}",
                    'alert_type_id': self.env.ref('it_campus_asset.alert_type_warranty').id,
                    'asset_id': asset.id,
                    'trigger_date': asset.warranty_end_date,
                })
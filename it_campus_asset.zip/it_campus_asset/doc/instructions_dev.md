# Developer Instructions for IT Asset Management 2

## Overview
This module provides a comprehensive IT asset management system for service providers, integrated with Odoo 18 Enterprise. It handles equipment tracking, incidents, contracts, billing, and more.

## Installation
1. Clone the repository.
2. Add the module to your Odoo addons path.
3. Install dependencies listed in `__manifest__.py`.
4. Run `odoo-bin -c config.conf --db <your_db> -i it_campus_asset`.

## Models
- `it.asset`: Manages equipment with fields for status, warranty, and amortization.
- `it.contract`: Handles client contracts with billing plans and SLA.
- ... (see models/ directory for full list)

## Testing
- Use `demo/demo_data.xml` for initial test data.
- Run unit tests in `tests/` with `odoo-bin -c config.conf --test-enable`.

## Database Schema
Refer to `doc/model_map.png` for entity relationship diagram.

## Best Practices
- Use `@api.depends` for computed fields.
- Ensure all views have unique IDs.
- Test security rules thoroughly.
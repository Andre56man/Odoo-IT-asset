from odoo import http
from odoo.http import request

class PortalController(http.Controller):

    @http.route('/my/assets', type='http', auth='user', website=True)
    def portal_assets(self, **kw):
        user = request.env.user
        assets = request.env['it.asset'].search([('user_final_id', '=', user.partner_id.id)])
        return request.render('it_campus_asset.portal_assets_template', {
            'assets': assets,
        })

    @http.route('/my/tickets', type='http', auth='user', website=True)
    def portal_tickets(self, **kw):
        user = request.env.user
        tickets = request.env['it.incident'].search([('user_final_id', '=', user.partner_id.id)])
        return request.render('it_campus_asset.portal_tickets_template', {
            'tickets': tickets,
        })

    @http.route('/my/invoices', type='http', auth='user', website=True)
    def portal_invoices(self, **kw):
        user = request.env.user
        invoices = request.env['account.move'].search([('partner_id', '=', user.partner_id.id), ('move_type', '=', 'out_invoice')])
        return request.render('it_campus_asset.portal_invoices_template', {
            'invoices': invoices,
        })
from odoo import api, SUPERUSER_ID

def post_init_hook(cr, registry):
    """Initialize demo data and alerts post-installation."""
    env = api.Environment(cr, SUPERUSER_ID, {})
    # Create initial alerts for demo purposes
    env['it.alert'].create_alerts_for_demo()
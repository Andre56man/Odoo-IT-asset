odoo.define('it_campus_asset.dashboard', function (require) {
    "use strict";

    var core = require('web.core');
    var rpc = require('web.rpc');
    var QWeb = core.qweb;

    var Dashboard = {
        start: function () {
            this._renderDashboard();
            this._setupRefresh();
        },

        _renderDashboard: function () {
            var self = this;
            rpc.query({
                model: 'it.asset',
                method: 'search_count',
                args: [[]],
            }).then(function (asset_count) {
                rpc.query({
                    model: 'it.incident',
                    method: 'search_count',
                    args: [[['status', '=', 'open']]],
                }).then(function (incident_count) {
                    var $content = QWeb.render('it_campus_asset.dashboard_template', {
                        asset_count: asset_count,
                        incident_count: incident_count,
                    });
                    $('#dashboard_content').html($content);
                });
            });
        },

        _setupRefresh: function () {
            setInterval(this._renderDashboard.bind(this), 60000); // Refresh every minute
        },
    };

    core.action_registry.add('it_dashboard', Dashboard);
});
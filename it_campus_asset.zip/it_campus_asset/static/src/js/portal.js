odoo.define('it_campus_asset.portal', function (require) {
    "use strict";

    var publicWidget = require('web.public.widget');

    publicWidget.registry.PortalFilter = publicWidget.Widget.extend({
        selector: '.portal-filter',
        start: function () {
            this.$el.on('change', 'select', this._onFilterChange.bind(this));
        },

        _onFilterChange: function (ev) {
            var $select = $(ev.currentTarget);
            var filter = $select.val();
            this._rpc({
                model: 'it.asset',
                method: 'search_read',
                args: [[['client_id', '=', this._getClientId()], ['status', '=', filter]], ['name']],
            }).then(function (assets) {
                $('#asset_list').html(assets.map(a => `<li>${a.name}</li>`).join(''));
            });
        },

        _getClientId: function () {
            return parseInt($('[name="client_id"]').val(), 10) || false;
        },
    });
});
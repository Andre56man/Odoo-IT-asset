from odoo.tests.common import TransactionCase
from datetime import timedelta

class TestAlerts(TransactionCase):

    def setUp(self):
        super(TestAlerts, self).setUp()
        self.client = self.env['res.partner'].create({'name': 'Test Client', 'customer_rank': 1})
        self.asset = self.env['it.asset'].create({
            'name': 'Test Asset',
            'client_id': self.client.id,
            'purchase_date': '2023-01-01',
            'warranty_end_date': fields.Date.today() + timedelta(days=15),
        })

    def test_alert_creation(self):
        self.env['it.alert.generator'].generate_alerts()
        alert = self.env['it.alert'].search([('asset_id', '=', self.asset.id)])
        self.assertTrue(alert)
        self.assertEqual(alert.alert_type_id.code, 'WARRANTY')
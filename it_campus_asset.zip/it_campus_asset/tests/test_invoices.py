from odoo.tests.common import TransactionCase

class TestInvoices(TransactionCase):

    def setUp(self):
        super(TestInvoices, self).setUp()
        self.client = self.env['res.partner'].create({'name': 'Test Client', 'customer_rank': 1})
        self.contract = self.env['it.contract'].create({
            'name': 'Test Contract',
            'client_id': self.client.id,
            'start_date': '2024-01-01',
            'end_date': '2024-12-31',
            'billing_frequency': 'monthly',
            'amount': 500.00,
        })
        self.billing_plan = self.env['it.billing.plan'].create({
            'name': 'Test Billing Plan',
            'frequency': 'monthly',
            'amount': 500.00,
            'due_date_days': 30,
            'contract_id': self.contract.id,
        })

    def test_invoice_generation(self):
        self.env['it.invoice.generator'].generate_invoices()
        invoice = self.env['account.move'].search([('partner_id', '=', self.client.id), ('move_type', '=', 'out_invoice')], limit=1)
        self.assertTrue(invoice)
        self.assertEqual(invoice.amount_total, 500.00)
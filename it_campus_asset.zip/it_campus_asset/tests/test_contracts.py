from odoo.tests.common import TransactionCase

class TestContracts(TransactionCase):

    def setUp(self):
        super(TestContracts, self).setUp()
        self.client = self.env['res.partner'].create({'name': 'Test Client', 'customer_rank': 1})
        self.contract = self.env['it.contract'].create({
            'name': 'Test Contract',
            'client_id': self.client.id,
            'start_date': '2024-01-01',
            'end_date': '2024-12-31',
            'billing_frequency': 'monthly',
            'amount': 500.00,
        })

    def test_contract_creation(self):
        self.assertEqual(self.contract.name, 'Test Contract')
        self.assertEqual(self.contract.client_id, self.client)

    def test_billing_plan_link(self):
        billing_plan = self.env['it.billing.plan'].create({
            'name': 'Test Billing Plan',
            'frequency': 'monthly',
            'amount': 500.00,
            'due_date_days': 30,
            'contract_id': self.contract.id,
        })
        self.assertEqual(self.contract.billing_plan_id, billing_plan)
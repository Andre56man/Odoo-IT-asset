from odoo.tests.common import TransactionCase
from datetime import datetime, timedelta

class TestSLA(TransactionCase):

    def setUp(self):
        super(TestSLA, self).setUp()
        self.client = self.env['res.partner'].create({'name': 'Test Client', 'customer_rank': 1})
        self.sla_template = self.env['it.sla.template'].create({
            'name': 'Test SLA',
            'response_time': 24,
            'resolution_time': 48,
            'penalty_rate': 0.10,
            'availability': 99.9,
        })
        self.incident = self.env['it.incident'].create({
            'name': 'Test Incident',
            'client_id': self.client.id,
            'create_date': datetime.now() - timedelta(hours=25),
        })

    def test_sla_evaluation(self):
        result = self.env['it.sla.evaluator'].evaluate_sla(self.incident)
        self.assertEqual(result['status'], 'violated')
        self.assertGreater(result['penalty'], 0.0)